function testTipos() {
    var resp = prompt("¿Qué tipo de dato es 'Juan'?");
    if(resp && resp.toLowerCase() === "string") {
      alert("¡Correcto!");
    } else {
      alert("Incorrecto. 'Juan' es un String.");
    }
  }
  
  function testIf() {
    var resp = prompt("Si x = 10, ¿se ejecuta el bloque if en: if(x > 5)? (Responde sí o no)");
    if(resp && (resp.toLowerCase() === "sí" || resp.toLowerCase() === "si")) {
      alert("¡Correcto!");
    } else {
      alert("Incorrecto. x > 5, por lo tanto se ejecuta.");
    }
  }
  
  function testBucles() {
    var resp = prompt("¿Cuántas iteraciones se ejecutan en: for(let i = 0; i < 3; i++) { ... }?");
    if(resp === "3") {
      alert("¡Correcto!");
    } else {
      alert("Incorrecto. Se ejecuta 3 veces.");
    }
  }
  
  function testArreglos() {
    var resp = prompt("¿Cómo se accede al segundo elemento del arreglo ['rojo', 'azul', 'verde']? (Ej: arreglo[1])");
    if(resp && (resp.toLowerCase() === "arreglo[1]" || resp.toLowerCase() === "colores[1]")) {
      alert("¡Correcto!");
    } else {
      alert("Incorrecto. Se accede con [1].");
    }
  }
  
  function testClases() {
    var resp = prompt("¿Con qué palabra se define una clase en JavaScript?");
    if(resp && resp.toLowerCase() === "class") {
      alert("¡Correcto!");
    } else {
      alert("Incorrecto. La palabra es 'class'.");
    }
  }
  
  function testMetodos() {
    var resp = prompt("¿Cómo se llama una función definida dentro de una clase?");
    if(resp && (resp.toLowerCase() === "método" || resp.toLowerCase() === "metodo")) {
      alert("¡Correcto!");
    } else {
      alert("Incorrecto. Se llama método.");
    }
  }