document.getElementById("registroForm").addEventListener("submit", function(event) {
    event.preventDefault();

    let creditos = parseFloat(document.getElementById("creditos").value);
    let codigoAsignatura = document.getElementById("codigoAsignatura").value;
    let nombreAsignatura = document.getElementById("nombreAsignatura").value;
    let nombreEstudiante = document.getElementById("nombreEstudiante").value;
    let codigoEstudiante = document.getElementById("codigoEstudiante").value;
    let calificacion = parseFloat(document.getElementById("calificacion").value);

    let tabla = document.getElementById("tablaRegistros").getElementsByTagName("tbody")[0];
    let nuevaFila = tabla.insertRow();

    nuevaFila.innerHTML = `
        <td>${creditos}</td>
        <td>${codigoAsignatura}</td>
        <td>${nombreAsignatura}</td>
        <td>${nombreEstudiante}</td>
        <td>${codigoEstudiante}</td>
        <td>${calificacion}</td>
    `;

    actualizarPromedio();
    document.getElementById("registroForm").reset();
});

function actualizarPromedio() {
    let tabla = document.getElementById("tablaRegistros").getElementsByTagName("tbody")[0];
    let filas = tabla.getElementsByTagName("tr");
    let sumaCalificaciones = 0;
    let sumaCreditos = 0;

    for (let i = 0; i < filas.length; i++) {
        let celdas = filas[i].getElementsByTagName("td");
        let creditos = parseFloat(celdas[0].textContent);
        let calificacion = parseFloat(celdas[5].textContent);
        
        sumaCalificaciones += calificacion * creditos;
        sumaCreditos += creditos;
    }

    let promedio = sumaCreditos > 0 ? (sumaCalificaciones / sumaCreditos).toFixed(2) : "4.15";
    document.getElementById("promedioSemestre").textContent = promedio;
}