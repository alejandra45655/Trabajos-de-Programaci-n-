// Clase base Figura
class Figura {
    constructor(x, y) {
        this.x = x;
        this.y = y;
    }

    obtenerCuadrante() {
        if (this.x > 0 && this.y > 0) return "1er cuadrante";
        if (this.x < 0 && this.y > 0) return "2do cuadrante";
        if (this.x < 0 && this.y < 0) return "3er cuadrante";
        if (this.x > 0 && this.y < 0) return "4to cuadrante";
        return "Sobre un eje";
    }
}

// Clase Triángulo
class Triangulo extends Figura {
    constructor(x, y, base, altura, lado1, lado2, lado3) {
        super(x, y);
        this.base = base;
        this.altura = altura;
        this.lado1 = lado1;
        this.lado2 = lado2;
        this.lado3 = lado3;
    }

    calcularArea() {
        return (this.base * this.altura) / 2;
    }

    calcularPerimetro() {
        return this.lado1 + this.lado2 + this.lado3;
    }
}

// Clase Cuadrado
class Cuadrado extends Figura {
    constructor(x, y, lado) {
        super(x, y);
        this.lado = lado;
    }

    calcularArea() {
        return this.lado * this.lado;
    }

    calcularPerimetro() {
        return 4 * this.lado;
    }
}

// Clase Círculo
class Circulo extends Figura {
    constructor(x, y, radio) {
        super(x, y);
        this.radio = radio;
    }

    calcularArea() {
        return Math.PI * this.radio * this.radio;
    }

    calcularPerimetro() {
        return 2 * Math.PI * this.radio;
    }
}

function mostrarResultados() {
    let triangulo = new Triangulo(2, -3, 5, 4, 3, 4, 5);
    let cuadrado = new Cuadrado(-2, 3, 4);
    let circulo = new Circulo(3, 3, 5);

    let resultado = `
        <h2>Resultados:</h2>
        <p><strong>Triángulo:</strong> Área = ${triangulo.calcularArea()} | Perímetro = ${triangulo.calcularPerimetro()} | ${triangulo.obtenerCuadrante()}</p>
        <p><strong>Cuadrado:</strong> Área = ${cuadrado.calcularArea()} | Perímetro = ${cuadrado.calcularPerimetro()} | ${cuadrado.obtenerCuadrante()}</p>
        <p><strong>Círculo:</strong> Área = ${circulo.calcularArea().toFixed(2)} | Perímetro = ${circulo.calcularPerimetro().toFixed(2)} | ${circulo.obtenerCuadrante()}</p>
    `;

    document.getElementById("resultado").innerHTML = resultado;
}