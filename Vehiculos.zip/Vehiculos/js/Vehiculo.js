class Vehiculo{
    constructor(marca, modelo, color)
    {
        this.marca=marca;
        this.modelo=modelo;
        this.color=color;
    }
    encender()
    {
        alert(`El ${this.marca} ${this.modelo} esta encendido!!`);
    }

    frenar(){
        alert(`El ${this.marca} ${this.color} freno!!!`);
    }
}

class Carro extends Vehiculo
{
    constructor(marca,modelo,color,puertas){
        super(marca,modelo,color);
        this.puertas=puertas;
    }
    encender(){
        alert(`El ${this.marca} ${this.color} con ${this.puertas} puertas esta encendido!!`);
    }
}

class Moto extends Vehiculo{
    
    encender()
    {
        alert(`la moto ${this.marca} ${this.modelo} esta encendida Run run run!!!`)
    }
}

const carrito = new Carro("Mazda","CX3","Rojo",5);
const motico = new Moto("Yamaha","R15", "Gris");

carrito.encender();
motico.encender();